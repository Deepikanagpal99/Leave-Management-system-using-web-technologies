<?php
 $login=false;
  $showError=false;
$server="localhost";
$username="root";
$password="";
$database="fb";
$con=mysqli_connect($server,$username,$password,$database);
if(!$con){
	die("error" .mysqli_connect_error());
}else{
if($_SERVER["REQUEST_METHOD"] =="POST")
{
		
			
			$username=$_POST["username"];
            $country=$_POST["country"];
            $email=$_POST["email"];


            $sql="SELECT * FROM users WHERE  username='$username' AND country='$country' AND email='$email'";
$res=mysqli_query($con,$sql);
$count=mysqli_num_rows($res);

            if($count >0 )
                {
                    $login=true;
                    session_start();
                     $_SESSION['loggedin']=true;
                    $_SESSION['username']=$username;
					 header("location:password.php");
                }
           

            else
            {
            $showError=true;
            }

}



}
?>


<!DOCTYPE html>
<html>
<head>
     <center><h1 class="p">Change password</h1></strong></p></center>
	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>

<?php
   if($login){
   echo "<script>alert('Welcome! you can change your password.')</script>";}

if($showError){
    echo "<script>alert('your are not  a user.')</script>";}
    ?>
	<title> Login</title>
   <form action="password.html" method="post" >
      <div class="container">
		<img src="farmer.jpg" height="50%">
			<div class="form-input">
				<input type="text" name="username" placeholder="Enter username " />
                <input type="text" name="country" placeholder="Enter favourate crop" />
                 <input type="text" name="email" placeholder="Enter mail-id" />
			</div>
			<p class="btn-login"><a href="password.php"><button>Submit</button></a></p>
		</form>
	</div>

</body>
</html>
