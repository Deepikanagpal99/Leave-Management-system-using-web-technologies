<?php
 $showAlert=false;
  $showError=0;
$server="localhost";
$username="root";
$password="";
$database="phpdb";
$con=mysqli_connect($server,$username,$password,$database);
if(!$con)
{
	die("error" .mysqli_connect_error());
}
else
{
        session_start();
		echo "your password has successfully changed!! "
       // $ousername= $_SESSION['username'];
        // if($_SERVER["REQUEST_METHOD"] == "POST")
         {
    
	
            //    $password=$_POST["password"];
            //    $confpassword=$_POST["confpassword"];
                               
              //                 if($password==$confpassword)
                              // {
           		//        $update1="UPDATE `users` SET `users`.`password` = '$password'  WHERE `users`.`username` = '$ousername'";
				       /* $query1=mysqli_query($con,$update1);
					        if($query1)
						        {
							      
							        header("location:login.php");
						        }
						        
                                }
                                else
						        {
						        	$showAlert=true;
						   
						   */                 
	//}
//}

                       
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="login.css">
	

	
</head>
<body>
 <?php


		   if($showAlert)
		   {

		   echo "<script>alert('password mismatch')</script>";
		   }
?>

  <form action="/new/password.php" method="post" >
      <div class="container">
		
                         
			
		</form>
	</div>

</body>
</html>

