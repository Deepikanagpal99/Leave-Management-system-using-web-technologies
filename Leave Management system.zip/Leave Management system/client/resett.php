<?php
include('connect.php');
$name=$_POST['name'];
$new=$_POST['new'];
$new1=$_POST['new1'];

$name = stripcslashes($name);    
$new = stripcslashes($new);   
$new1 = stripcslashes($new1);    
$name = mysqli_real_escape_string($conn, $name);
$new = mysqli_real_escape_string($conn, $new);
$new1 = mysqli_real_escape_string($conn, $new1);  

if (isset($_POST['save'])) {
 if($new==$new1){

	$sql="UPDATE employee SET password='$new' where username='$name'"; 
	$result = mysqli_query($conn, $sql);  
          
	if(! $result){ 
 	echo "<h1>Password notupdated</h1>";  
	header("refresh:2; reset.html");
	}
	else{  
        echo "<h1><center>Password Updated</center></h1>"; 
	header("refresh:0; url=login.php"); 
	}  
  }
else{
echo "<h1><center>please enter same Passwords</center></h1>";
header("refresh:2; reset.html");
}
}
     
?>  


