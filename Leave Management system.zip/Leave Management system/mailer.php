<?php
require_once "Mail.php";
function mailer($recipient,$msg){
$from = '<chinninagpal@gmail.com>';
$to = '<'.$recipient.'>';
$subject = 'Leave Request Status For Employee Registered with '.$recipient;
$body = $msg;
$status = false; // initially set to false
$headers = array(
    'From' => $from,
    'To' => $to,
    'Subject' => $subject
);

$smtp = Mail::factory('smtp', array(
        'host' => 'ssl://smtp.gmail.com',
        'port' => '466',
        'auth' => true,
        'username' => 'chinninagpal@gmail.com',
        'password' => 'chinni'
    ));

$mail = $smtp->send($to, $headers, $body);

if (PEAR::isError($mail)) {
    $status = false;
} else {
    $status = true; // return true on succesful sending
}
return $status;
}
?>
