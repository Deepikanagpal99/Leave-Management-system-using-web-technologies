<html>
<head>
<title>::Leave Management::</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<body style="background-color:#92a8d1;">
<?php
echo "<div class = 'heading'>";
echo "<h1>Leave Management System</h1>";
include 'navi.php';
echo "<center>";
echo "<h2> The Leave Management System is an Intranet based application that can be accessed throughout the organization or a specified group/Dept. This system can be used to automate the workflow of leave applications and their approvals. The periodic crediting of leave is also automated. 
 ! </h2>";
echo "</center>";
echo "</div>";
?>